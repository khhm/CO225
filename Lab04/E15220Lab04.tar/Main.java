public class Main {
    // If user call the programme incorrectly here print write way to call
    public static void printUsage(){
	    System.out.println("\nUsage:");
    	    System.out.println("java Main F:first_Name");
            System.out.println("            or            ");
            System.out.println("java Main L:last_Name\n");
    	    System.exit(0);
    }
    
    public static void main(String [] args) { 
        // If there isn't input argument here handle it
        try{
            //divide input into two substrings and store identifire(whether first or last name) and name
            String name_type=args[0].substring(0, 1); 
            String input_name=args[0].substring(2);
            //If identifire(whether first or last name) not equal F or L retun programme
            if(!name_type.toLowerCase().equals("f") && !name_type.toLowerCase().equals("l") || !args[0].substring(1, 2).equals(":")){
               printUsage();
            }
            //Create ContactsDB object
	    ContactsDB contact = new ContactsDB("contacts.csv","Name","Phone 1 - Value"); 
            contact.PrintContact(name_type,input_name);
        }
        catch(Exception e){
            printUsage();
        }
    }
}
