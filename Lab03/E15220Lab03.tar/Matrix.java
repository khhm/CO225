public class Matrix extends Thread{
    //initializes variables for dimensions and Arrays
    private int row;
    private int col;
    private int K;
    private int [][] A;
    private int [][] B;
    private int [][] C;
    
    public Matrix(int row,int col, int[][] A,
      int[][] B, int[][] C) {
        this.row = row;
        this.col = col;
        this.A = A;
        this.B = B;
        this.C = C;
        this.K = B.length;
    }
    
    int s,k;
    public void run() {
        //Each thread calculate one row of answer matrix -> C[row][i]
        for(int i=0;i<col;i++){
	  for(s=0, k=0; k<K; k++)        
	     s += A[row][k] * B[k][i];  
	  C[row][i] = s;
        }
    }   
}