public class Main{
    
    //Declares Arrays A,B,C, and an Array or WorkerThreads
    public static int [][] A = new int[2000][2000]; //Initializes Matrix A
    
    public static int [][] B = new int[2000][2000];  //Initializes Matrix B
   
    
    public static int M = A.length; //row size A
    public static int N = B[0].length; //column size of B

    public static int [][] C = new int [M][N];
    //creates M Worker threads. Each thread Calculates row of answer Matrix C
    //using threads matrix multiplication is faster than normal matrix multiplication where the answer matrix is large
    /*for this test case
          using normal multiplication Run Time : 73682 ms
          using threads  Run Time : 40663 ms
    */
    public static Matrix [] Threads = new Matrix[M];
    
    public static void print_matrix(int [][] a) {
	for(int i=0; i < M; i++) {
	    for(int j=0; j< N; j++) 
		System.out.printf("%5d",a[i][j]); 
	    System.out.println();
	}
    }

    public static void main(String[] args) throws InterruptedException { 
        //Create Matrix A and B include ones to test code
        for(int i=0;i<2000;i++){
            for(int j=0;j<2000;j++){
                A[i][j]=1;
                B[i][j]=1;
            }        
        }
        //Calculate run time
        final long startTime = System.nanoTime();
        //check if multipication can be done, if not return
        if(A[0].length != B.length) { 
	    System.out.println("Cannnot multiply"); 
            return;
	}
        //Run Time : 75431055 ms
        //Run Time : 6850478 ms
        int i,j;
        for (i = 0; i<M; i++){
                Threads[i] = new Matrix(i,N,A,B,C); //call Matrix 
                Threads[i].start(); 
        }
        
        for(i = 0; i<M; i++){
            Threads[i].join();
        }
        //Outputs the Values of Matrix C
        print_matrix(C); // see if the multipication is correct
        final long duration = System.nanoTime() - startTime;
        System.out.println("\nRun Time : "+duration/1000000+" ms");
    }
}